brazilianday = int(input("Digite o dia: "))

if brazilianday < 1 or brazilianday > 31:
    print("Dia errado. Precisa ser de 1 até 31.")
else:
    brazilianmonth = int(input("Digite o mês: "))
    if brazilianmonth < 1 or brazilianmonth > 12:
        print("Mês errado. Precisa ser de 1 até 12.")
    else:
        brazilianyear = int(input("Digite o ano: "))
        if brazilianyear >= 9999 or brazilianyear < 0000: 
            print("Ano errado. Precisa ser um valor válido.")
        else:
            print(f"{brazilianmonth} / {brazilianday} / {brazilianyear}")
