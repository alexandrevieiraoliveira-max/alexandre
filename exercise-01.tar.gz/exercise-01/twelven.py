a = int(input("Digite o valor de a: "))
b = int(input("Digite o valor de b: "))
c = int(input("Digite o valor de c: "))

delta = (b ** 2) - (4 * a * c)

resultado = delta / (2 * a)

print(f"O resultado é: {resultado}")