x = int(input("Digite um número: "))

print(f"O resultado é: {(x // 100) * 100}")